# ParentalGuard (Android, Kotlin)

Open in Android Studio (Koala or newer) -> Sync -> Run on a device (not an emulator, for usage stats).

First run: create a parent PIN, set the daily limit, grant Usage Access and
"Display over other apps", then tap "Save and start protection".

Blocked apps use package names, e.g. com.google.android.youtube.

Notes
- The monitoring notification is intentional and must stay visible.
- This version stores rules locally. Remote control from the parent's phone needs a backend (e.g. Firebase).
- Preventing the child from uninstalling the app: use Device Admin / Family Link-style APIs, with the child's knowledge.
- Google Play requires a declaration for PACKAGE_USAGE_STATS and SYSTEM_ALERT_WINDOW.
