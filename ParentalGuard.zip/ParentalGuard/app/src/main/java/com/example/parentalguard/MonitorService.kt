package com.example.parentalguard

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import java.util.Calendar

/**
 * Transparent monitor: always shows a visible notification so the child knows
 * screen-time rules are active. Do not hide it.
 */
class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var policy: Policy
    private val allowed = setOf("com.android.dialer", "com.google.android.dialer", "com.android.emergency")

    private val tick = object : Runnable {
        override fun run() { check(); handler.postDelayed(this, 2000) }
    }

    override fun onCreate() {
        super.onCreate()
        policy = Policy(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("pg", "Screen time rules", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "pg")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Screen-time rules are active")
            .setContentText("A parent has set limits on this device.")
            .setOngoing(true).build()
        startForeground(1, n)
        handler.post(tick)
    }

    private fun check() {
        if (System.currentTimeMillis() < policy.unlockUntil) return
        val pkg = currentForegroundPackage() ?: return
        if (pkg == packageName || pkg in allowed || isLauncher(pkg)) return
        val overLimit = todayMinutes() >= policy.dailyLimitMin
        if (pkg in policy.blocked || overLimit) {
            startActivity(Intent(this, BlockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("reason", if (overLimit) "Daily limit reached" else "This app is blocked"))
        }
    }

    private fun currentForegroundPackage(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(now - 15_000, now)
        val e = UsageEvents.Event()
        var last: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) last = e.packageName
        }
        return last
    }

    private fun todayMinutes(): Long {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
        }.timeInMillis
        val stats = usm.queryAndAggregateUsageStats(start, System.currentTimeMillis())
        return stats.filterKeys { it != packageName && !isLauncher(it) }
            .values.sumOf { it.totalTimeInForeground } / 60_000
    }

    private fun isLauncher(pkg: String): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return packageManager.resolveActivity(i, 0)?.activityInfo?.packageName == pkg
    }

    override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
}
