package com.example.parentalguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (Policy(ctx).pinHash != null)
            ContextCompat.startForegroundService(ctx, Intent(ctx, MonitorService::class.java))
    }
}
