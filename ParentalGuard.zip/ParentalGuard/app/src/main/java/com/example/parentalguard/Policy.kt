package com.example.parentalguard

import android.content.Context
import java.security.MessageDigest

/** Stores the parent's rules locally. Replace with a server-synced source for remote control. */
class Policy(ctx: Context) {
    private val p = ctx.getSharedPreferences("policy", Context.MODE_PRIVATE)

    var pinHash: String?
        get() = p.getString("pin", null)
        set(v) { p.edit().putString("pin", v).apply() }

    var dailyLimitMin: Int
        get() = p.getInt("limit", 120)
        set(v) { p.edit().putInt("limit", v).apply() }

    var blocked: Set<String>
        get() = HashSet(p.getStringSet("blocked", emptySet()) ?: emptySet())
        set(v) { p.edit().putStringSet("blocked", HashSet(v)).apply() }

    /** Epoch millis until which a parent has temporarily lifted restrictions. */
    var unlockUntil: Long
        get() = p.getLong("unlock", 0L)
        set(v) { p.edit().putLong("unlock", v).apply() }

    fun checkPin(pin: String) = pinHash != null && pinHash == hash(pin)
    fun setPin(pin: String) { pinHash = hash(pin) }

    private fun hash(s: String) = MessageDigest.getInstance("SHA-256")
        .digest(("pg-salt:$s").toByteArray()).joinToString("") { "%02x".format(it) }
}
