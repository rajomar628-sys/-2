package com.example.parentalguard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*

class BlockActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val policy = Policy(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
        }
        col.addView(TextView(this).apply {
            text = intent.getStringExtra("reason") ?: "Blocked"
            textSize = 24f; gravity = Gravity.CENTER
        })
        col.addView(Button(this).apply {
            text = "Go to home screen"
            setOnClickListener { goHome() }
        })
        val pin = EditText(this).apply {
            hint = "Parent PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        col.addView(pin)
        col.addView(Button(this).apply {
            text = "Parent: allow 15 minutes"
            setOnClickListener {
                if (policy.checkPin(pin.text.toString())) {
                    policy.unlockUntil = System.currentTimeMillis() + 15 * 60_000
                    finish()
                } else Toast.makeText(context, "Wrong PIN", Toast.LENGTH_SHORT).show()
            }
        })
        setContentView(col)
    }

    private val context get() = this

    @Deprecated("Back goes home instead of returning to the blocked app")
    override fun onBackPressed() = goHome()

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
