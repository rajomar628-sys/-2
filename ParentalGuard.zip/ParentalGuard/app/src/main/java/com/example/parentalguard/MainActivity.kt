package com.example.parentalguard

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.text.InputType
import android.widget.*
import androidx.core.content.ContextCompat

/** Parent-facing screen. Locked behind a PIN. */
class MainActivity : Activity() {
    private lateinit var policy: Policy

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        policy = Policy(this)
        if (policy.pinHash == null) showSetPin() else showLogin()
    }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48)
    }

    private fun showSetPin() {
        val c = column()
        c.addView(TextView(this).apply { text = "Create a parent PIN"; textSize = 22f })
        val pin = pinField(); c.addView(pin)
        c.addView(Button(this).apply {
            text = "Save"
            setOnClickListener {
                if (pin.text.length >= 4) { policy.setPin(pin.text.toString()); showSettings() }
                else toast("At least 4 digits")
            }
        })
        setContentView(c)
    }

    private fun showLogin() {
        val c = column()
        c.addView(TextView(this).apply { text = "Parent PIN"; textSize = 22f })
        val pin = pinField(); c.addView(pin)
        c.addView(Button(this).apply {
            text = "Enter"
            setOnClickListener {
                if (policy.checkPin(pin.text.toString())) showSettings() else toast("Wrong PIN")
            }
        })
        setContentView(c)
    }

    private fun showSettings() {
        val c = column()
        c.addView(TextView(this).apply { text = "Daily limit (minutes)"; textSize = 18f })
        val limit = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(policy.dailyLimitMin.toString())
        }
        c.addView(limit)
        c.addView(TextView(this).apply {
            text = "Blocked apps (package names, comma-separated)"; textSize = 18f
        })
        val blocked = EditText(this).apply { setText(policy.blocked.joinToString(",")) }
        c.addView(blocked)

        c.addView(Button(this).apply {
            text = "1. Grant Usage Access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        })
        c.addView(Button(this).apply {
            text = "2. Allow display over other apps"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        c.addView(Button(this).apply {
            text = "3. Save and start protection"
            setOnClickListener {
                policy.dailyLimitMin = limit.text.toString().toIntOrNull() ?: 120
                policy.blocked = blocked.text.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                if (!hasUsageAccess()) { toast("Grant Usage Access first"); return@setOnClickListener }
                ContextCompat.startForegroundService(context, Intent(context, MonitorService::class.java))
                toast("Protection is on")
            }
        })
        setContentView(ScrollView(this).apply { addView(c) })
    }

    private val context get() = this
    private fun pinField() = EditText(this).apply {
        hint = "PIN"
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
}
